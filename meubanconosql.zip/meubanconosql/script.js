//Comunicação Com o Banco de Dados - NO-SQL - JSON
fetch('dados.json').then(resposta => resposta.json()).then(banco => {
    console.log(banco)
    
    //FRONT-END
    document.getElementById('imagem').innerHTML = banco[3].imagemProdutos.imagem001
    document.getElementById('produto').innerHTML = banco[0].produtos.prod123
    document.getElementById('preço').innerHTML = banco[2].preço.preço790
    document.getElementById('vededor').innerHTML = banco[1].vendedor.vend456
})